export default [
  {
    id: "0001",
    img: "https://fdn2.gsmarena.com/vv/pics/oneplus/oneplus-8-2.jpg",
    price: 300.00.toFixed(2),
    title: "OnePlus 9T",
    description: "It's a hat. You wear it on your head.",
    promo: "Use code PROVOPICKUP for free shipping if you wish to pick up your hat in the Provo office."
  },
  {
    id: "0002",
    img: "https://fdn2.gsmarena.com/vv/pics/oneplus/oneplus-8-polar-silver.jpg",
    price: 250.00.toFixed(2),
    title: "OnePlus 8T",
    description: "It's a beanie. You wear it on your head. 100% Acrylic with leather logo patch // One size fits all",
    promo: "Use code PROVOPICKUP for free shipping if you wish to pick up your hat in the Provo office."
  },
  {
    id: "0003",
    img: "https://fdn2.gsmarena.com/vv/pics/oneplus/oneplus-8t-lunar.jpg",
    price: 200.00.toFixed(2),
    title: "OnePlus 7",
    description: "Make life convenient with a lanyard. You add keys. It goes on your neck.",
    promo: "Use code PROVOPICKUP for free shipping if you wish to pick up your hat in the Provo office."
  },
  {
    id: "0004",
    img: "https://fdn2.gsmarena.com/vv/pics/oneplus/oneplus-nord-1.jpg",
    price: 150.00.toFixed(2),
    title: "OnePlus Nord",
    description: "Independent Trading Company // (55% Cotton / 45% Polyester)",
    promo: "Use code PROVOPICKUP for free shipping if you wish to pick up your hat in the Provo office."
  }
]