import React from "react";
import { Link } from 'react-router-dom';
import { connect } from "react-redux";

import './Nav.css';

import ShoppingCart from 'react-icons/lib/fa/shopping-cart';



function Nav({ items }) {
  return (
    <div id="Nav__container">
      <div id="Nav__linksContainer">
        <Link to="/" className="navLink">
			<span className="Nav__label">
				<svg height="60px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 214 74" id="icon-brand-2020"><path d="M79.1 37.1c0-3.9-1.8-7-5.4-7-3.6 0-5.5 3.1-5.5 7s1.8 7 5.5 7c3.7-.1 5.4-3.1 5.4-7m-14.9 0c0-5.9 3.7-10.3 9.5-10.3s9.5 4.4 9.5 10.3-3.7 10.2-9.5 10.2-9.5-4.3-9.5-10.2M86.6 27.2h4.1l6.6 11c.6 1.1 1.4 2.8 1.4 2.8h.1s-.1-2-.1-3.4V27.2h3.9v19.7h-3.9L91.9 36c-.6-1-1.4-2.7-1.4-2.7h-.1s.1 2.1.1 3.4v10.2h-3.9V27.2zM107 27.2h14.5v3.3H111v4.4h9.2v3.3H111v5.3h10.6v3.4H107zM129.6 36.5h4.1c2.1 0 3.2-1.2 3.2-2.9 0-1.8-1.2-2.9-3.1-2.9h-4.2v5.8zm-4.1-9.3h8.7c2.3 0 4 .7 5.2 1.8 1.1 1.1 1.8 2.7 1.8 4.5 0 3.7-2.5 6.2-6.6 6.2h-4.8v7.1h-4.1V27.2zM144 27.2h4v16.3h9.2v3.4H144zM159.4 40.5V27.2h4v13.4c0 2 1 3.5 3.7 3.5 2.5 0 3.7-1.5 3.7-3.5V27.2h4v13.4c0 4.2-2.6 6.7-7.6 6.7-5.2-.1-7.8-2.5-7.8-6.8M177.6 40.8h3.9c.3 2.4 1.6 3.3 4.4 3.3 2 0 3.8-.7 3.8-2.5 0-1.9-1.9-2.3-4.9-3-3.5-.8-6.8-1.7-6.8-5.8 0-3.9 3.2-5.9 7.5-5.9 4.4 0 7.3 2.2 7.6 6.1h-3.8c-.2-2-1.8-3-3.8-3-2.1 0-3.6.9-3.6 2.3 0 1.6 1.4 2.1 4.3 2.7 4.1.9 7.4 1.8 7.4 6.1 0 4-3.2 6.2-7.7 6.2-5.2 0-8.2-2.4-8.3-6.5M20 20.2v33.6h33.6V34.6h-3.7v15.5H23.7V24h15.5v-3.8zM49.9 14v6.2h-6.3V24h6.3v6.2h3.7V24h6.2v-3.8h-6.2V14z"></path><path d="M39.2 45.1V28.7h-3.3c0 1.1-.4 2-1 2.5s-1.5.7-2.6.7h-.4v2.7h3.5v10.5h3.8z"></path></svg>
			</span>
		</Link>

        <Link to="/checkout" className="navLink">
			<div id="Nav__checkoutContainer">
			  <div id="Nav__itemsInCart"> {items} </div>
			  <ShoppingCart id="Nav__shoppingCart" />
			</div>
        </Link>
      </div>
    </div>
  )
}

function mapStateToProps(state) {
  return {
    items: state.cart.length
  };
}

export default connect(mapStateToProps)(Nav);