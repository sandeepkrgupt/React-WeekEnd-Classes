export function posts(defStore:any=[],action:any){
  switch(action.type){
      case 'DELETE_POST':
          console.log('Inside DELETE_POST case.. (posts reducer)');
          return defStore; // return new Store !
    default:   
    console.log('Post reducer default case')   
        console.log(defStore);
        return defStore;
  }
}