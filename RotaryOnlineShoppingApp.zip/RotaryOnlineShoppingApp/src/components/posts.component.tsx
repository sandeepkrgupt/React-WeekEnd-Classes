import React from 'react';
import axios from 'axios';
// 1. install axios/jquery  [npm install axios --save]
// 2. use axios to make ajax request - ?
// 3. print the response in console.

export default class PostsComponent extends React.Component<any,any> {
    
    constructor(props:any){
        super(props);        
    }
    
    render() {
        var allpoststoberendered  = this.props.allposts.map((p:any)=> <li> {p.title} </li>);
        return <div>
            <h1> All Posts </h1>
            {/* list of posts -> title */}
            <ul>
                {allpoststoberendered}
            </ul>
        </div>
    }
}