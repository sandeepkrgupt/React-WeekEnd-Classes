import {connect} from 'react-redux';
import { Dispatch, bindActionCreators } from 'redux';
import * as AllActions from '../actions/actions';
import App from './App';

// state -> app state (store)
function mapStateToProps(storeDataFromProvider:any){
        return {
            allproducts:storeDataFromProvider.products,
            allposts:storeDataFromProvider.posts
        }
}

function mapDispatchToProps(dispatcher:Dispatch){
    return bindActionCreators(AllActions,dispatcher);
}   
export var WrapperApp = connect(mapStateToProps,mapDispatchToProps)(App);


// function A(){
//     return function (x:number){
//         console.log(x);
//     }
// }

// A()(10); // function currying !