import React from 'react';

// No Render !
// No component life cycle methods !
// No state !


export default function FunctionalComponent(){
    return (
    <h1> Message From Functional Component !</h1>
    )
}

// import React from 'react'
// export const Component = (props) => {
//     return(
//         <div>
          
//         </div>
//     )
// }
// export default Component