import React from 'react';
import logo from './logo.svg';
import './App.css';
import Product from './product.component';
import ProductModel from '../product.model';
import ListOfProducts from './listofproducts.component';
import { BrowserRouter, Switch, Route, Link } from 'react-router-dom';
import PostsComponent from './posts.component';

class App extends React.Component {
  
render(){
   console.log(this.props);
  // this.props -> allproducts,allposts,IncrmentLIke(),...

 return <BrowserRouter>
 
<nav className="navbar navbar-inverse">
  <div className="container-fluid">
    <div className="navbar-header">
      <Link className="navbar-brand" to="/">Shopping Cart With Redux & Router App</Link>
    </div>
    <ul className="nav navbar-nav">
      <li className="active"><Link to="/">Home</Link></li>     
      <li><Link to="/posts">Posts</Link></li> 
    </ul>
  </div>
</nav>
  <Switch>
    <Route path="/" exact render={()=><ListOfProducts {...this.props} />}></Route>
    <Route path="/posts" render={()=><PostsComponent {...this.props} />}></Route>
  </Switch>
</BrowserRouter>


     
}
}
export default App;











  //render() {
    // return <div>
    //   <BasicComponent msg="Hi"/>
    //   <BasicComponent msg="Hola" />
    //   <BasicComponent msg="Namaste" />
    //   <BasicComponent  />
    // </div>   
 // }