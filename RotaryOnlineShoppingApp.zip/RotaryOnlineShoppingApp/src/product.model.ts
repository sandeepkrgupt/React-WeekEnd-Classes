export default class ProductModel{
    constructor(
        public id:number,
        public name:string,
        public price:number,
        public imageUrl:string,
        public likes:number,
        public rating:number,
        public quantity:number
        ){

    }

}